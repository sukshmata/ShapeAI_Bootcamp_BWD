import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p> A basic bootcamp on webdevelopment with help of rect.js</p>
    </div>
  );
}

export default Info;
