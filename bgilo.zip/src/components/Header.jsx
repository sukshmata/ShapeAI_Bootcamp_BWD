import React from "react";

function Header() {
  return <header>ATHMAKURI SUKSHMATA</header>;
}

export default Header;
